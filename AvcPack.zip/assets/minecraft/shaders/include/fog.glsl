#version 150

// mine.avcgames.ru: густой туман в адской земле.
// Над адом биом «багровый лес», и у игрока там всегда ночь — туман почти чисто красный. В обычном мире
// игра рисует туман только у горизонта; здесь, если цвет тумана такой, туман подтягивается к игроку:
// начинается сразу и густеет к 32 блокам. У границы ада цвет смешивается с обычным — туман нарастает плавно.

float avc_hell(vec4 fogColor) {
    // В аду у игрока всегда ночь: туман там тёмный и красный. Закатное зарево тоже красное, но яркое —
    // поэтому только тёмный красный. Обычный ночной туман синеватый (синего больше красного) — не трогаем.
    float r = fogColor.r;
    if (r < 0.002 || r > 0.12) return 0.0;
    float red = (r - max(fogColor.g, fogColor.b)) / r;
    return clamp((red - 0.05) * 5.0, 0.0, 1.0);
}

vec4 linear_fog(vec4 inColor, float vertexDistance, float fogStart, float fogEnd, vec4 fogColor) {
    // Интерфейс, предметы в руке и в инвентаре рисуются с выключенным туманом (начало «бесконечно далеко») — не трогаем
    if (fogStart < fogEnd && fogStart < 100000.0) {
        float k = avc_hell(fogColor);
        fogStart = mix(fogStart, 0.0, k);
        fogEnd = mix(fogEnd, 32.0, k);
    }
    if (vertexDistance <= fogStart) {
        return inColor;
    }

    float fogValue = vertexDistance < fogEnd ? smoothstep(fogStart, fogEnd, vertexDistance) : 1.0;
    return vec4(mix(inColor.rgb, fogColor.rgb, fogValue * fogColor.a), inColor.a);
}

float linear_fog_fade(float vertexDistance, float fogStart, float fogEnd) {
    if (vertexDistance <= fogStart) {
        return 1.0;
    } else if (vertexDistance >= fogEnd) {
        return 0.0;
    }

    return smoothstep(fogEnd, fogStart, vertexDistance);
}

float fog_distance(mat4 modelViewMat, vec3 pos, int shape) {
    if (shape == 0) {
        return length((modelViewMat * vec4(pos, 1.0)).xyz);
    } else {
        float distXZ = length((modelViewMat * vec4(pos.x, 0.0, pos.z, 1.0)).xyz);
        float distY = length((modelViewMat * vec4(0.0, pos.y, 0.0, 1.0)).xyz);
        return max(distXZ, distY);
    }
}

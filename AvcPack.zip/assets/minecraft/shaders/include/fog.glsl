#version 150

// mine.avcgames.ru: густой туман в адской земле.
// Над адом биом «багровый лес» — его туман почти чисто красный. В обычном мире игра рисует туман
// только у горизонта; здесь, если цвет тумана красный (и это не закат — у заката зелёного больше синего),
// туман подтягивается к игроку: начинается сразу и густеет к 32 блокам. У границы ада красный
// смешивается с обычным — туман нарастает плавно.

float avc_hell(vec4 fogColor) {
    float r = fogColor.r;
    float g = fogColor.g;
    float b = fogColor.b;
    if (r < 0.004) return 0.0;
    if (g > b * 1.1) return 0.0; // закат: оранжевый, зелёного больше синего
    float red = (r - max(g, b)) / r;
    return clamp((red - 0.15) * 2.5, 0.0, 1.0);
}

vec4 linear_fog(vec4 inColor, float vertexDistance, float fogStart, float fogEnd, vec4 fogColor) {
    float k = avc_hell(fogColor);
    fogStart = mix(fogStart, 0.0, k);
    fogEnd = mix(fogEnd, 32.0, k);
    if (vertexDistance <= fogStart) {
        return inColor;
    }

    float fogValue = vertexDistance < fogEnd ? smoothstep(fogStart, fogEnd, vertexDistance) : 1.0;
    return vec4(mix(inColor.rgb, fogColor.rgb, fogValue * fogColor.a), inColor.a);
}

float linear_fog_fade(float vertexDistance, float fogStart, float fogEnd) {
    if (vertexDistance <= fogStart) {
        return 1.0;
    } else if (vertexDistance >= fogEnd) {
        return 0.0;
    }

    return smoothstep(fogEnd, fogStart, vertexDistance);
}

float fog_distance(mat4 modelViewMat, vec3 pos, int shape) {
    if (shape == 0) {
        return length((modelViewMat * vec4(pos, 1.0)).xyz);
    } else {
        float distXZ = length((modelViewMat * vec4(pos.x, 0.0, pos.z, 1.0)).xyz);
        float distY = length((modelViewMat * vec4(0.0, pos.y, 0.0, 1.0)).xyz);
        return max(distXZ, distY);
    }
}
